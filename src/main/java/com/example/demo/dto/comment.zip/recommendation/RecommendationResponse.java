package com.example.demo.dto.recommendation;

public class RecommendationResponse {
}
