package com.example.demo.dto.task;

public class TaskHistoryResponse {
}
