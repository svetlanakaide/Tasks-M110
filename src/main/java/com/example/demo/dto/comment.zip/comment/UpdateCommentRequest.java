package com.example.demo.dto.comment;

public class UpdateCommentRequest {
}
