package com.example.demo.dto.task;

public class ChangeTaskStatusRequest {
}
