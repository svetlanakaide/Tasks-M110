package com.example.demo.dto.skill;

public class SkillResponse {
}
