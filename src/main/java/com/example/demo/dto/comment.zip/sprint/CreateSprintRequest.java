package com.example.demo.dto.sprint;

public class CreateSprintRequest {
}
