package com.example.demo.dto.user;
import com.example.demo.*;

public record UserShortResponse(

        Long id,

        String username

) {
    public static UserShortResponse from(User user) {
        if (user == null) {
            return null;
        }
        return new UserShortResponse(user.getId(), user.getUsername());
    }
}