package com.example.demo.dto.project;

public class AddProjectMemberRequest {
}
